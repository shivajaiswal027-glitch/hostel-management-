import React, { useState, useEffect } from 'react';
import { 
  User, UserPlus, Shield, ShieldAlert, Key, ClipboardList, CreditCard, 
  MapPin, CheckCircle, XCircle, Users, Activity, Bell, FileText, 
  Coffee, Calendar, AlertTriangle, Moon, Sun, Plus, Check, RefreshCw, Send, Sparkles, LogOut, Camera
} from 'lucide-react';

export default function App() {
  // --- Simulated Multi-User DB Registers ---
  const [usersDb, setUsersDb] = useState([
    { name: 'Aarav Sharma', email: 'student@college.edu', roll: 'NITK-CSE-2023-45', password: 'Password123', role: 'STUDENT', dept: 'Computer Science', branch: 'Information Technology', year: '3', gender: 'MALE' },
    { name: 'Lead Warden Admin', email: 'admin@college.edu', roll: 'NITK-ADMIN-01', password: 'Password123', role: 'ADMIN', dept: 'Administration', branch: 'Warden Office', year: 'N/A', gender: 'MALE' },
    { name: 'Security Guard Ram', email: 'security@college.edu', roll: 'NITK-SEC-03', password: 'Password123', role: 'SECURITY', dept: 'Security Desk', branch: 'Main Gate', year: 'N/A', gender: 'MALE' },
    { name: 'Ramesh Sharma (Parent)', email: 'ramesh@college.edu', roll: 'NITK-GUEST-09', password: 'Password123', role: 'GUEST', dept: 'Visitor', branch: 'Parent', year: 'N/A', gender: 'MALE' }
  ]);
  const [currentUser, setCurrentUser] = useState(null);

  // Login states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [activePortal, setActivePortal] = useState('student'); // student, admin, guest, security
  const [notifications, setNotifications] = useState([
    { id: 1, title: "Fee Reminder", message: "Mess bill for June 2026 is due in 3 days.", type: "warning", read: false },
    { id: 2, title: "Leave Approved", message: "Your night-out leave request has been approved by Warden.", type: "success", read: false },
    { id: 3, title: "Gym Alert", message: "Hostel Gym is currently at 90% capacity.", type: "danger", read: true }
  ]);
  const [showBell, setShowBell] = useState(false);

  // --- Student State ---
  const [studentLeaves, setStudentLeaves] = useState([
    { id: 1, type: 'Night-out', startDate: '2026-06-15', endDate: '2026-06-16', reason: 'Family function', status: 'APPROVED', qrPass: 'LEAVE_A7B9C3F0' },
    { id: 2, type: 'Home Leave', startDate: '2026-06-20', endDate: '2026-06-25', reason: 'Semester break', status: 'PENDING', qrPass: '' }
  ]);
  const [leaveType, setLeaveType] = useState('NIGHT_OUT');
  const [leaveStart, setLeaveStart] = useState('');
  const [leaveEnd, setLeaveEnd] = useState('');
  const [leaveReason, setLeaveReason] = useState('');
  
  const [studentComplaints, setStudentComplaints] = useState([
    { id: 1, title: 'Wi-Fi slow', category: 'Wi-Fi', status: 'IN_PROGRESS', date: '2026-06-12' },
    { id: 2, title: 'Bathroom tap leak', category: 'Plumbing', status: 'OPEN', date: '2026-06-13' }
  ]);
  const [complaintTitle, setComplaintTitle] = useState('');
  const [complaintCategory, setComplaintCategory] = useState('Plumbing');
  const [complaintDesc, setComplaintDesc] = useState('');

  const [walletBalance, setWalletBalance] = useState(1500.00);
  const [messAbsentDates, setMessAbsentDates] = useState([]);
  
  // --- Guest State ---
  const [guestBookings, setGuestBookings] = useState([
    { id: 1, guestName: 'Ramesh Sharma', checkIn: '2026-06-18', checkOut: '2026-06-20', total: 2400, status: 'APPROVED', qrPass: 'GUEST_B3F281' }
  ]);
  const [guestName, setGuestName] = useState('');
  const [guestRelation, setGuestRelation] = useState('Parent');
  const [guestCheckIn, setGuestCheckIn] = useState('');
  const [guestCheckOut, setGuestCheckOut] = useState('');

  // --- Admin State ---
  const [occupancyTotal, setOccupancyTotal] = useState(150);
  const [occupancyMax, setOccupancyMax] = useState(200);
  const [adminLeaves, setAdminLeaves] = useState([
    { id: 1, studentName: 'Aarav Sharma', type: 'Night-out', dates: 'June 15 - June 16', reason: 'Family function', status: 'PENDING' },
    { id: 2, studentName: 'Aarushi Goel', type: 'Home Leave', dates: 'June 20 - June 25', reason: 'Semester break', status: 'PENDING' }
  ]);
  const [complaintsCount, setComplaintsCount] = useState(12);
  const [financials, setFinancials] = useState({ collected: 450000, pending: 85000 });
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastTarget, setBroadcastTarget] = useState('ALL');

  // --- Security / AI State ---
  const [gateLogs, setGateLogs] = useState([
    { id: 1, name: 'Aarav Sharma', direction: 'IN', method: 'FACE_ID', timestamp: '18:30:12' },
    { id: 2, name: 'Aarushi Goel', direction: 'OUT', method: 'QR_CODE', timestamp: '17:45:00' },
    { id: 3, name: 'Ramesh Sharma (Guest)', direction: 'IN', method: 'MANUAL', timestamp: '16:20:05' }
  ]);
  const [scannedFaceName, setScannedFaceName] = useState('Aarav Sharma');
  const [verificationResult, setVerificationResult] = useState(null);
  const [isVerifying, setIsVerifying] = useState(false);

  // --- Laundry/Gym Slots State ---
  const [laundryBookings, setLaundryBookings] = useState([]);
  const [gymBookings, setGymBookings] = useState([]);
  const [facilityCrowd, setFacilityCrowd] = useState({ gym: 72, commonRoom: 45 });

  // Webhook and Razorpay Simulation
  const [payingBill, setPayingBill] = useState(null);

  // --- Add Student Modal State ---
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentEmail, setNewStudentEmail] = useState('');
  const [newStudentRoll, setNewStudentRoll] = useState('');
  const [newStudentDept, setNewStudentDept] = useState('Computer Science');
  const [newStudentBranch, setNewStudentBranch] = useState('Information Technology');
  const [newStudentYear, setNewStudentYear] = useState('1');
  const [newStudentGender, setNewStudentGender] = useState('MALE');
  const [newStudentCredentials, setNewStudentCredentials] = useState(null);

  const handleAddStudent = (e) => {
    e.preventDefault();
    if (!newStudentName || !newStudentEmail || !newStudentRoll) return;

    const generatedPassword = `NITK-${Math.floor(1000 + Math.random() * 9500)}`;

    const newStudentObj = {
      name: newStudentName,
      email: newStudentEmail,
      roll: newStudentRoll,
      password: generatedPassword,
      role: 'STUDENT',
      dept: newStudentDept,
      branch: newStudentBranch,
      year: newStudentYear,
      gender: newStudentGender
    };

    setUsersDb(prev => [...prev, newStudentObj]);
    setOccupancyTotal(prev => Math.min(occupancyMax, prev + 1));

    setNewStudentCredentials({
      name: newStudentName,
      email: newStudentEmail,
      password: generatedPassword,
      roll: newStudentRoll
    });

    addNotification(
      "Student Registered", 
      `Profile created for ${newStudentName}. Credentials generated.`, 
      "success"
    );
    
    setNewStudentName('');
    setNewStudentEmail('');
    setNewStudentRoll('');
    setShowAddStudentModal(false);
  };

  const handleLogin = (e) => {
    if (e) e.preventDefault();
    setLoginError('');

    const matchedUser = usersDb.find(
      u => u.email.toLowerCase() === loginEmail.toLowerCase() && u.password === loginPassword
    );

    if (matchedUser) {
      setCurrentUser(matchedUser);
      if (matchedUser.role === 'STUDENT') {
        setActivePortal('student');
      } else if (matchedUser.role === 'ADMIN') {
        setActivePortal('admin');
      } else if (matchedUser.role === 'SECURITY') {
        setActivePortal('security');
      } else if (matchedUser.role === 'GUEST') {
        setActivePortal('guest');
      }
      addNotification("Login Successful", `Welcome, ${matchedUser.name}!`, "success");
      setLoginEmail('');
      setLoginPassword('');
    } else {
      setLoginError('Invalid Unique ID/Email or Password.');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    addNotification("Logged Out", "Signed out of session.", "info");
  };

  const addNotification = (title, message, type = "info") => {
    setNotifications(prev => [
      { id: Date.now(), title, message, type, read: false },
      ...prev
    ]);
  };

  // Run AI Crowd simulator
  useEffect(() => {
    const timer = setInterval(() => {
      setFacilityCrowd(prev => {
        const nextGym = Math.min(100, Math.max(10, prev.gym + (Math.random() > 0.5 ? 4 : -4)));
        const nextCommon = Math.min(100, Math.max(10, prev.commonRoom + (Math.random() > 0.5 ? 3 : -3)));
        
        if (nextGym >= 85) {
          addNotification("Gym Capacity Alert", `Hostel Gym occupancy has reached ${nextGym}%. Wait list activated.`, "danger");
        }
        
        return { gym: nextGym, commonRoom: nextCommon };
      });
    }, 12000);
    return () => clearInterval(timer);
  }, []);

  const handleApplyLeave = (e) => {
    e.preventDefault();
    if (!leaveStart || !leaveEnd || !leaveReason) return;
    const newLeave = {
      id: Date.now(),
      type: leaveType === 'NIGHT_OUT' ? 'Night-out' : 'Home Leave',
      startDate: leaveStart,
      endDate: leaveEnd,
      reason: leaveReason,
      status: 'PENDING',
      qrPass: ''
    };
    setStudentLeaves([newLeave, ...studentLeaves]);
    
    // Simulating admin list sync
    setAdminLeaves([
      { id: newLeave.id, studentName: 'Aarav Sharma', type: newLeave.type, dates: `${leaveStart} to ${leaveEnd}`, reason: leaveReason, status: 'PENDING' },
      ...adminLeaves
    ]);

    addNotification("Leave Application", "Your leave application has been submitted to your warden.", "info");
    setLeaveStart('');
    setLeaveEnd('');
    setLeaveReason('');
  };

  const handleCreateComplaint = (e) => {
    e.preventDefault();
    if (!complaintTitle || !complaintDesc) return;
    const newComplaint = {
      id: Date.now(),
      title: complaintTitle,
      category: complaintCategory,
      status: 'OPEN',
      date: new Date().toISOString().split('T')[0]
    };
    setStudentComplaints([newComplaint, ...studentComplaints]);
    setComplaintsCount(prev => prev + 1);
    addNotification("Complaint Registered", `Ticket registered under ${complaintCategory}.`, "success");
    setComplaintTitle('');
    setComplaintDesc('');
  };

  const handleBookGuest = (e) => {
    e.preventDefault();
    if (!guestName || !guestCheckIn || !guestCheckOut) return;
    const price = 1200 * (new Date(guestCheckOut) - new Date(guestCheckIn)) / (1000 * 60 * 60 * 24);
    const newBooking = {
      id: Date.now(),
      guestName,
      checkIn: guestCheckIn,
      checkOut: guestCheckOut,
      total: price || 1200,
      status: 'PENDING',
      qrPass: ''
    };
    setGuestBookings([newBooking, ...guestBookings]);
    addNotification("Guest Stay Initiated", `Booking requested for ${guestName}. Redirecting to checkout.`, "info");
    setGuestName('');
    setGuestCheckIn('');
    setGuestCheckOut('');
  };

  const handleApproveLeave = (id) => {
    setAdminLeaves(prev => prev.map(l => l.id === id ? { ...l, status: 'APPROVED' } : l));
    setStudentLeaves(prev => prev.map(l => l.id === id ? { ...l, status: 'APPROVED', qrPass: `LEAVE_${Math.random().toString(36).substring(7).toUpperCase()}` } : l));
    addNotification("Leave Request Approved", "Leave has been approved. Digital QR Gate Pass generated.", "success");
  };

  const handleRejectLeave = (id) => {
    setAdminLeaves(prev => prev.map(l => l.id === id ? { ...l, status: 'REJECTED' } : l));
    setStudentLeaves(prev => prev.map(l => l.id === id ? { ...l, status: 'REJECTED' } : l));
    addNotification("Leave Request Rejected", "Leave request was rejected by Warden.", "danger");
  };

  const handleBroadcast = (e) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;
    addNotification(`Broadcast: ${broadcastTitle}`, broadcastMessage, "info");
    setBroadcastTitle('');
    setBroadcastMessage('');
  };

  const simulateFaceScan = () => {
    setIsVerifying(true);
    setVerificationResult(null);
    setTimeout(() => {
      setIsVerifying(false);
      const matched = Math.random() > 0.15; // 85% match chance
      const similarity = (85 + Math.random() * 14.8).toFixed(1);
      
      if (matched) {
        const direction = gateLogs[0]?.direction === 'IN' ? 'OUT' : 'IN';
        const newLog = {
          id: Date.now(),
          name: scannedFaceName,
          direction,
          method: 'FACE_ID',
          timestamp: new Date().toTimeString().split(' ')[0]
        };
        setGateLogs([newLog, ...gateLogs]);
        setVerificationResult({
          success: true,
          similarity,
          direction,
          message: `Verified match at ${similarity}% confidence threshold.`
        });
        if (scannedFaceName === 'Aarav Sharma') {
          addNotification("Check In/Out", `Gate logs: ${scannedFaceName} checked ${direction} via FaceID.`, "success");
        }
      } else {
        setVerificationResult({
          success: false,
          similarity: (60 + Math.random() * 20).toFixed(1),
          message: "No database match. Identity unverified."
        });
        addNotification("Security Alert", "Gate camera detected unidentified face attempt.", "danger");
      }
    }, 1500);
  };

  const simulateBillPayment = (bill) => {
    setPayingBill(bill);
    setTimeout(() => {
      setPayingBill(null);
      setWalletBalance(prev => prev - bill.amount);
      addNotification("Payment Success", `Successfully paid ₹${bill.amount} for ${bill.type} Bill. Receipt generated.`, "success");
    }, 1800);
  };

  const autoAllocateRooms = () => {
    setOccupancyTotal(prev => Math.min(occupancyMax, prev + 8));
    addNotification("Auto Room Allocator", "Smart room allocation matching completed. Allocated 8 unassigned students.", "success");
  };

  const toggleMessAbsent = (date) => {
    if (messAbsentDates.includes(date)) {
      setMessAbsentDates(messAbsentDates.filter(d => d !== date));
    } else {
      setMessAbsentDates([...messAbsentDates, date]);
      addNotification("Food Waste Savings", `Meal leave saved for ${date}. Thank you!`, "success");
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 relative font-sans">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />

        <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6 relative z-10">
          <div className="text-center space-y-2">
            <div className="inline-flex bg-gradient-to-tr from-indigo-500 to-purple-500 p-3 rounded-2xl shadow-lg shadow-indigo-500/20 mb-2">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
              Hostel Hub Central Sign In
            </h2>
            <p className="text-xs text-slate-400">Enter your credentials provided by the Admin after registration</p>
          </div>

          {loginError && (
            <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl p-3 text-xs text-center font-medium animate-pulse">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Unique ID / Email</label>
              <input 
                type="email" 
                placeholder="student@college.edu"
                required
                value={loginEmail}
                onChange={e => setLoginEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 mt-1 text-slate-100 bg-slate-950"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Password</label>
              <input 
                type="password" 
                placeholder="••••••••"
                required
                value={loginPassword}
                onChange={e => setLoginPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 mt-1 text-slate-100 bg-slate-950"
              />
            </div>

            <button 
              type="submit"
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-3 rounded-xl hover:opacity-90 transition-all shadow-lg shadow-indigo-600/15"
            >
              Sign In to Portal
            </button>
          </form>

          <div className="border-t border-slate-800 pt-4 space-y-3">
            <p className="text-[10px] font-bold text-slate-400 uppercase text-center">Quick Demo Accounts (Pre-seeded)</p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button 
                onClick={() => { setLoginEmail('student@college.edu'); setLoginPassword('Password123'); }}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 p-2.5 rounded-xl font-semibold transition-colors"
              >
                👤 Student Demo
              </button>
              <button 
                onClick={() => { setLoginEmail('admin@college.edu'); setLoginPassword('Password123'); }}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 p-2.5 rounded-xl font-semibold transition-colors"
              >
                🔑 Warden Admin
              </button>
              <button 
                onClick={() => { setLoginEmail('security@college.edu'); setLoginPassword('Password123'); }}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 p-2.5 rounded-xl font-semibold transition-colors"
              >
                👮 Security Guard
              </button>
              <button 
                onClick={() => { setLoginEmail('ramesh@college.edu'); setLoginPassword('Password123'); }}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 p-2.5 rounded-xl font-semibold transition-colors"
              >
                🏠 Parent Guest
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Premium Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-indigo-500 to-purple-500 p-2.5 rounded-xl shadow-lg shadow-indigo-500/20">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              {process.env.COLLEGE_NAME || 'NIT'} Hostel Hub
            </h1>
            <p className="text-xs text-slate-400 font-medium">Single Source of Truth Portal</p>
          </div>
        </div>

        {/* Portal Nav */}
        <nav className="hidden md:flex bg-slate-950/60 p-1.5 rounded-xl border border-slate-800/80">
          {[
            { id: 'student', label: 'Student Portal', icon: User },
            { id: 'admin', label: 'Warden Portal', icon: ShieldAlert },
            { id: 'guest', label: 'Guest Portal', icon: ClipboardList },
            { id: 'security', label: 'Security Desk', icon: Key }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActivePortal(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ${
                  activePortal === tab.id 
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/15'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Action Panel */}
        <div className="flex items-center gap-4">
          {/* Real-time Bell */}
          <div className="relative">
            <button 
              onClick={() => setShowBell(!showBell)}
              className="relative p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/50 hover:bg-slate-800 transition-colors"
            >
              <Bell className="w-5 h-5 text-slate-300" />
              {notifications.some(n => !n.read) && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
              )}
            </button>

            {showBell && (
              <div className="absolute right-0 mt-3 w-80 bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl p-4 overflow-hidden animate-in fade-in slide-in-from-top-3 duration-200">
                <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
                  <h3 className="font-bold text-sm text-slate-200">Notifications</h3>
                  <button 
                    onClick={() => setNotifications(notifications.map(n => ({...n, read: true})))}
                    className="text-xs text-indigo-400 hover:underline"
                  >
                    Mark read
                  </button>
                </div>
                <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                  {notifications.map(n => (
                    <div 
                      key={n.id} 
                      className={`p-2.5 rounded-lg border text-xs transition-colors ${
                        n.read ? 'bg-slate-950/40 border-slate-900' : 'bg-slate-800/40 border-slate-700/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-slate-200">{n.title}</span>
                        <span className={`w-2 h-2 rounded-full ${
                          n.type === 'danger' ? 'bg-rose-500' : n.type === 'warning' ? 'bg-amber-500' : 'bg-emerald-500'
                        }`} />
                      </div>
                      <p className="text-slate-400">{n.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="hidden sm:flex items-center gap-4 border-l border-slate-800 pl-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-pink-500 flex items-center justify-center font-bold text-white text-sm shadow uppercase">
                {currentUser ? currentUser.name.substring(0, 2) : 'US'}
              </div>
              <div className="text-left">
                <p className="text-xs font-bold">{currentUser ? currentUser.name : 'User Profile'}</p>
                <p className="text-[10px] text-slate-400 font-semibold">{currentUser ? `${currentUser.role} | ${currentUser.roll}` : 'Guest session'}</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 transition-colors"
              title="Logout Session"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body Layout */}
      <main className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full space-y-8">
        
        {/* Dynamic Mobile Portal Selector */}
        <div className="md:hidden flex bg-slate-900 p-1 rounded-xl border border-slate-800 overflow-x-auto gap-1">
          {[
            { id: 'student', label: 'Student' },
            { id: 'admin', label: 'Warden' },
            { id: 'guest', label: 'Guest' },
            { id: 'security', label: 'Security' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActivePortal(tab.id)}
              className={`flex-1 text-center py-2 px-3 rounded-lg text-xs font-bold whitespace-nowrap ${
                activePortal === tab.id ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ---------------- STUDENT PORTAL VIEW ---------------- */}
        {activePortal === 'student' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
            {/* Left/Middle Columns */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Allocation Card */}
              <div className="bg-gradient-to-r from-slate-900 to-indigo-950/40 border border-slate-800/80 rounded-3xl p-6 relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl" />
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-1 bg-indigo-500/20 text-indigo-300 rounded-full">
                      Assigned Room Allocation
                    </span>
                    <h2 className="text-3xl font-extrabold mt-2 tracking-tight">Block A, Room 102</h2>
                    <p className="text-slate-400 text-sm mt-1">Bed Number: <span className="font-bold text-slate-200">102-B</span> | Type: Double Occupancy</p>
                  </div>
                  <div className="flex items-center gap-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                    <Users className="w-5 h-5 text-indigo-400" />
                    <div>
                      <p className="text-xs text-slate-400">Roommate</p>
                      <p className="text-sm font-bold">Harsh Vardhan</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mess Management & Absent Tracker */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Coffee className="w-5 h-5 text-amber-500" />
                    <h3 className="font-extrabold text-lg">Mess & Meal Manager</h3>
                  </div>
                  <span className="text-xs text-slate-400">Reduce food wastage by declaring absence</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Today's Menu */}
                  <div className="bg-slate-950/50 p-4.5 rounded-2xl border border-slate-800/60">
                    <h4 className="font-bold text-sm mb-3 text-slate-300">Today's Menu</h4>
                    <ul className="space-y-2 text-xs">
                      <li className="flex justify-between py-1 border-b border-slate-900"><span className="text-slate-400">Breakfast</span> <span className="font-medium">Idli Sambhar, Tea</span></li>
                      <li className="flex justify-between py-1 border-b border-slate-900"><span className="text-slate-400">Lunch</span> <span className="font-medium">Roti, Dal Tadka, Paneer, Rice</span></li>
                      <li className="flex justify-between py-1"><span className="text-slate-400">Dinner</span> <span className="font-medium">Aloo Gobhi, Rice, Kheer</span></li>
                    </ul>
                  </div>

                  {/* Absent Checkbox */}
                  <div>
                    <h4 className="font-bold text-sm mb-3 text-slate-300">Mark Absentees</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {['June 14', 'June 15', 'June 16', 'June 17'].map(date => {
                        const isAbsent = messAbsentDates.includes(date);
                        return (
                          <button
                            key={date}
                            onClick={() => toggleMessAbsent(date)}
                            className={`p-3 rounded-xl border text-center transition-all duration-200 ${
                              isAbsent 
                                ? 'bg-rose-500/20 border-rose-500 text-rose-300 font-bold'
                                : 'bg-slate-950/30 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            <p className="text-[10px] font-semibold">Date</p>
                            <p className="text-xs">{date}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Tickets & Complaints */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-indigo-400" />
                    <h3 className="font-extrabold text-lg">Raise Maintenance complaint</h3>
                  </div>
                </div>

                <form onSubmit={handleCreateComplaint} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2 space-y-4">
                    <input 
                      type="text" 
                      placeholder="Title (e.g., Water heater not heating)"
                      value={complaintTitle}
                      onChange={e => setComplaintTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500"
                    />
                    <textarea 
                      placeholder="Provide full description (block, room, details)..."
                      value={complaintDesc}
                      onChange={e => setComplaintDesc(e.target.value)}
                      rows="2"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div className="space-y-4">
                    <select 
                      value={complaintCategory} 
                      onChange={e => setComplaintCategory(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Plumbing">Plumbing</option>
                      <option value="Electrical">Electrical</option>
                      <option value="Wi-Fi">Wi-Fi / Internet</option>
                      <option value="Other">Other</option>
                    </select>
                    <button 
                      type="submit"
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 py-3 rounded-xl text-sm font-bold text-white hover:opacity-95 transition-opacity"
                    >
                      Submit Ticket
                    </button>
                  </div>
                </form>

                {/* Complaint History */}
                <div className="space-y-2">
                  <h4 className="font-bold text-xs text-slate-400 uppercase tracking-wider">Registered Tickets</h4>
                  {studentComplaints.map(t => (
                    <div key={t.id} className="flex justify-between items-center bg-slate-950/40 border border-slate-900 rounded-xl p-3.5 text-sm">
                      <div>
                        <p className="font-bold text-slate-200">{t.title}</p>
                        <p className="text-[10px] text-slate-400">Category: {t.category} | Created: {t.date}</p>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        t.status === 'OPEN' ? 'bg-amber-500/20 text-amber-300' : 'bg-indigo-500/20 text-indigo-300'
                      }`}>
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Right Side Column (Leaves & Fees Wallet) */}
            <div className="space-y-8">
              
              {/* Fee Wallet Card */}
              <div className="bg-gradient-to-tr from-slate-900 to-indigo-950 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl" />
                <h3 className="font-bold text-slate-400 text-xs uppercase tracking-wider">Fees & Balance Wallet</h3>
                <div>
                  <p className="text-3xl font-extrabold">₹{walletBalance.toFixed(2)}</p>
                  <p className="text-xs text-indigo-400 mt-1">Hostel deposits security wallet</p>
                </div>

                <div className="space-y-2 border-t border-slate-800/80 pt-4">
                  <h4 className="text-xs font-semibold text-slate-300">Pending Invoices</h4>
                  {[
                    { id: 'bill-1', type: 'Hostel Rent', amount: 6000, due: '2026-06-30' },
                    { id: 'bill-2', type: 'Electricity Bill', amount: 450, due: '2026-06-25' }
                  ].map(b => (
                    <div key={b.id} className="flex items-center justify-between text-xs bg-slate-950/50 p-3 rounded-xl border border-slate-900">
                      <div>
                        <p className="font-bold">{b.type}</p>
                        <p className="text-[10px] text-slate-400">Due: {b.due}</p>
                      </div>
                      <button 
                        onClick={() => simulateBillPayment(b)}
                        disabled={payingBill === b.id}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-lg transition-colors"
                      >
                        {payingBill === b.id ? 'Paying...' : `Pay ₹${b.amount}`}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Leave Requests Apply & Passes */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
                <div>
                  <h3 className="font-extrabold text-lg">Leave passes & QRs</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Apply for night-out or home leaves</p>
                </div>

                <form onSubmit={handleApplyLeave} className="space-y-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Leave Type</label>
                    <select 
                      value={leaveType}
                      onChange={e => setLeaveType(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    >
                      <option value="NIGHT_OUT">Night-Out (1 night)</option>
                      <option value="HOME_LEAVE">Home Leave (multiple days)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Start Date</label>
                      <input 
                        type="date"
                        value={leaveStart}
                        onChange={e => setLeaveStart(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">End Date</label>
                      <input 
                        type="date"
                        value={leaveEnd}
                        onChange={e => setLeaveEnd(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Reason</label>
                    <input 
                      type="text" 
                      placeholder="e.g., Visiting home for weekend"
                      value={leaveReason}
                      onChange={e => setLeaveReason(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs focus:outline-none mt-1"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 py-2.5 rounded-xl text-xs font-bold transition-all border border-slate-700/50"
                  >
                    Submit Application
                  </button>
                </form>

                {/* Digital QR Passes List */}
                <div className="space-y-3 pt-3 border-t border-slate-800/80">
                  <h4 className="font-bold text-xs text-slate-400 uppercase">My Digital Passes</h4>
                  {studentLeaves.map(l => (
                    <div key={l.id} className="bg-slate-950/60 p-4 rounded-2xl border border-slate-900 space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <div>
                          <p className="font-bold">{l.type}</p>
                          <p className="text-[10px] text-slate-400">{l.startDate} to {l.endDate}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          l.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300' : l.status === 'REJECTED' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {l.status}
                        </span>
                      </div>

                      {l.status === 'APPROVED' && (
                        <div className="flex items-center gap-3 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                          {/* Simulated QR Code */}
                          <div className="w-14 h-14 bg-white p-1 rounded-lg flex flex-col justify-between border">
                            <div className="grid grid-cols-3 gap-0.5 w-full h-full">
                              <div className="bg-black"></div><div className="bg-black"></div><div className="bg-white"></div>
                              <div className="bg-white"></div><div className="bg-black"></div><div className="bg-black"></div>
                              <div className="bg-black"></div><div className="bg-white"></div><div className="bg-black"></div>
                            </div>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-indigo-400 uppercase">Approved Pass Token</p>
                            <p className="text-xs font-mono text-slate-200">{l.qrPass}</p>
                            <p className="text-[9px] text-slate-400 mt-0.5">Show at entry points to scan</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ---------------- ADMIN / WARDEN PORTAL VIEW ---------------- */}
        {activePortal === 'admin' && (
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Live Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                <p className="text-xs text-slate-400 font-bold uppercase">Total Occupancy</p>
                <div className="flex justify-between items-end">
                  <h3 className="text-2xl font-extrabold">{occupancyTotal} / {occupancyMax}</h3>
                  <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full">
                    {((occupancyTotal/occupancyMax)*100).toFixed(0)}% Rate
                  </span>
                </div>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                <p className="text-xs text-slate-400 font-bold uppercase">Collected Fees</p>
                <div className="flex justify-between items-end">
                  <h3 className="text-2xl font-extrabold text-emerald-400">₹{financials.collected.toLocaleString()}</h3>
                  <span className="text-[10px] font-bold text-slate-400">This Term</span>
                </div>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                <p className="text-xs text-slate-400 font-bold uppercase">Outstanding Dues</p>
                <div className="flex justify-between items-end">
                  <h3 className="text-2xl font-extrabold text-rose-400">₹{financials.pending.toLocaleString()}</h3>
                  <span className="text-[10px] font-bold text-rose-500/20 bg-rose-500/10 px-2 py-0.5 rounded-full">
                    Alert Active
                  </span>
                </div>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-2">
                <p className="text-xs text-slate-400 font-bold uppercase">Open Complaints</p>
                <div className="flex justify-between items-end">
                  <h3 className="text-2xl font-extrabold text-amber-400">{complaintsCount} Tickets</h3>
                  <span className="text-[10px] font-bold text-slate-400">Active</span>
                </div>
              </div>

            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Approval Requests Queue */}
              <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="font-extrabold text-lg">Leaves Approval Workflows</h3>
                  <span className="text-xs font-medium text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-full">
                    {adminLeaves.filter(l => l.status === 'PENDING').length} Pending
                  </span>
                </div>

                <div className="space-y-3">
                  {adminLeaves.map(request => (
                    <div key={request.id} className="bg-slate-950/60 border border-slate-900 rounded-2xl p-4.5 space-y-3.5">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-slate-200">{request.studentName}</p>
                          <p className="text-xs text-slate-400">Type: <span className="font-bold text-slate-300">{request.type}</span> | Dates: {request.dates}</p>
                          <p className="text-xs text-slate-400 mt-1">Reason: <span className="italic text-slate-300">"{request.reason}"</span></p>
                        </div>
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          request.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300' : request.status === 'REJECTED' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {request.status}
                        </span>
                      </div>

                      {request.status === 'PENDING' && (
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-900">
                          <button
                            onClick={() => handleApproveLeave(request.id)}
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 rounded-xl transition-all"
                          >
                            Approve & Issue QR Pass
                          </button>
                          <button
                            onClick={() => handleRejectLeave(request.id)}
                            className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-2 px-4 rounded-xl transition-all"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Administrative Quick Actions & AI tools */}
              <div className="space-y-8">
                
                {/* Resident Registration Panel */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                    <UserPlus className="w-5 h-5 text-indigo-400" />
                    <h3 className="font-extrabold text-lg">Resident Registration</h3>
                  </div>
                  <p className="text-xs text-slate-400">Add a new student profile manually to the hostel database and allocate beds immediately.</p>
                  
                  <button 
                    onClick={() => setShowAddStudentModal(true)}
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 text-white text-sm font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-600/10 flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Register New Student
                  </button>
                </div>

                {/* Smart Allocations Panel */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                  <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                    <Sparkles className="w-5 h-5 text-indigo-400" />
                    <h3 className="font-extrabold text-lg">Smart Allocations</h3>
                  </div>
                  <p className="text-xs text-slate-400">Run matching algorithms to automatically bundle students into available beds based on department and year of study.</p>
                  
                  <button 
                    onClick={autoAllocateRooms}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-600/10 flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Run Auto Allocation Heuristic
                  </button>
                </div>

                {/* Unified Broadcast Console */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                  <h3 className="font-extrabold text-lg">Multi-channel Broadcast</h3>
                  <form onSubmit={handleBroadcast} className="space-y-3">
                    <input 
                      type="text" 
                      placeholder="Announcement Title"
                      value={broadcastTitle}
                      onChange={e => setBroadcastTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500"
                    />
                    <textarea 
                      placeholder="Compose broadcast message (sent to In-App, Email, WhatsApp, and SMS fallback)..."
                      value={broadcastMessage}
                      onChange={e => setBroadcastMessage(e.target.value)}
                      rows="3"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500"
                    />
                    <div className="flex gap-2">
                      <select 
                        value={broadcastTarget}
                        onChange={e => setBroadcastTarget(e.target.value)}
                        className="bg-slate-950 border border-slate-800 rounded-xl px-2 py-1.5 text-[10px] text-slate-400"
                      >
                        <option value="ALL">All Blocks</option>
                        <option value="BLOCK_A">Block A Only</option>
                        <option value="BLOCK_D">Block D Only</option>
                      </select>
                      <button 
                        type="submit"
                        className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold py-1.5 rounded-xl transition-all border border-slate-700/50"
                      >
                        Send Broadcast
                      </button>
                    </div>
                  </form>
                </div>

              </div>

            </div>
          </div>
        )}

        {/* ---------------- GUEST PORTAL VIEW ---------------- */}
        {activePortal === 'guest' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
            {/* Left booking form */}
            <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
              <div>
                <h3 className="font-extrabold text-lg">Guest stay booking panel</h3>
                <p className="text-xs text-slate-400 mt-0.5">Request temporary guest accommodation (parents, alumni, visiting faculty)</p>
              </div>

              <form onSubmit={handleBookGuest} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Guest Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Ramesh Sharma"
                      value={guestName}
                      onChange={e => setGuestName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Relation to Student</label>
                    <select 
                      value={guestRelation} 
                      onChange={e => setGuestRelation(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    >
                      <option value="Parent">Parent</option>
                      <option value="Sibling">Sibling</option>
                      <option value="Alumni">Alumni / Visitor</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Check-in Date</label>
                    <input 
                      type="date"
                      value={guestCheckIn}
                      onChange={e => setGuestCheckIn(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Check-out Date</label>
                    <input 
                      type="date"
                      value={guestCheckOut}
                      onChange={e => setGuestCheckOut(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    />
                  </div>
                </div>

                <div className="md:col-span-2 pt-4 border-t border-slate-800/80 mt-2 flex justify-between items-center">
                  <div>
                    <p className="text-xs text-slate-400">Total Charged Rate</p>
                    <p className="text-lg font-bold">₹1,200 / Night</p>
                  </div>
                  <button 
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-6 py-3 rounded-xl transition-all"
                  >
                    Initiate Booking & Checkout
                  </button>
                </div>
              </form>
            </div>

            {/* Right bookings details */}
            <div className="space-y-8">
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-extrabold text-lg">My Guest passes</h3>
                
                {guestBookings.map(b => (
                  <div key={b.id} className="bg-slate-950/60 border border-slate-900 rounded-2xl p-4 space-y-3.5">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold text-slate-200">{b.guestName}</p>
                        <p className="text-[10px] text-slate-400">Checkin: {b.checkIn} | Checkout: {b.checkOut}</p>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold ${
                        b.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {b.status}
                      </span>
                    </div>

                    {b.status === 'APPROVED' && (
                      <div className="flex items-center gap-3 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                        {/* Simulated QR Code */}
                        <div className="w-12 h-12 bg-white p-1 rounded flex flex-col justify-between">
                          <div className="grid grid-cols-2 gap-0.5 w-full h-full bg-black"></div>
                        </div>
                        <div>
                          <p className="text-[9px] font-bold text-indigo-400 uppercase">Temporary Guest QR</p>
                          <p className="text-xs font-mono text-slate-200">{b.qrPass}</p>
                          <p className="text-[8px] text-slate-400 mt-0.5">Valid only during booking duration</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- SECURITY DESK / AI GATE SCAN VIEW ---------------- */}
        {activePortal === 'security' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
            
            {/* Live Camera Scanner */}
            <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-indigo-400" />
                  <h3 className="font-extrabold text-lg">AI Gate Camera feed</h3>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  Device ONLINE
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Camera Viewport Simulation */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl aspect-video flex flex-col items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />
                  
                  {isVerifying ? (
                    <div className="flex flex-col items-center gap-3">
                      <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
                      <p className="text-xs font-bold text-slate-400">Comparing details with DB face vectors...</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2.5">
                      <div className="w-16 h-16 rounded-full border-2 border-dashed border-indigo-500 flex items-center justify-center text-indigo-400">
                        <Camera className="w-8 h-8" />
                      </div>
                      <p className="text-xs text-slate-400">Scan Student/Guest Face at checkpoint</p>
                    </div>
                  )}

                  {/* Laser line effect */}
                  {isVerifying && (
                    <div className="absolute left-0 right-0 h-1 bg-indigo-500/80 shadow-[0_0_8px_indigo] animate-bounce top-0" />
                  )}
                </div>

                {/* Identity Input and controls */}
                <div className="space-y-4">
                  <h4 className="font-bold text-sm text-slate-300">Identity Selection Simulation</h4>
                  
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Select Target resident</label>
                    <select 
                      value={scannedFaceName}
                      onChange={e => setScannedFaceName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-indigo-500 mt-1"
                    >
                      <option value="Aarav Sharma">Aarav Sharma (Student - Active)</option>
                      <option value="Aarushi Goel">Aarushi Goel (Student - Active)</option>
                      <option value="Ramesh Sharma (Guest)">Ramesh Sharma (Guest - Approved)</option>
                      <option value="Unidentified Person">Unknown Stranger (Trigger Failure)</option>
                    </select>
                  </div>

                  <button
                    onClick={simulateFaceScan}
                    disabled={isVerifying}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow"
                  >
                    Trigger Camera Face Capture
                  </button>

                  {/* Comparison Result */}
                  {verificationResult && (
                    <div className={`p-4 rounded-xl border text-xs space-y-1 ${
                      verificationResult.success 
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' 
                        : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                    }`}>
                      <p className="font-bold">{verificationResult.success ? 'Identity VERIFIED' : 'Access DENIED'}</p>
                      <p>{verificationResult.message}</p>
                      {verificationResult.success && (
                        <p className="font-semibold text-slate-300 mt-1">Logged gate direction: {verificationResult.direction}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Checkin Logs feed */}
            <div className="space-y-8">
              <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <h3 className="font-extrabold text-lg">Realtime gate logs</h3>
                
                <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                  {gateLogs.map(log => (
                    <div key={log.id} className="flex justify-between items-center text-xs bg-slate-950/50 p-3 rounded-xl border border-slate-900">
                      <div>
                        <p className="font-bold text-slate-200">{log.name}</p>
                        <p className="text-[10px] text-slate-400">Method: {log.method} | Time: {log.timestamp}</p>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold ${
                        log.direction === 'IN' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        Checked {log.direction}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 text-center text-slate-500 text-xs">
        <p>© 2026 {process.env.COLLEGE_NAME || 'National Institute of Technology'}. All Rights Reserved.</p>
        <p className="text-[10px] mt-1 text-slate-600">Unified Student & Guest Gate Registers System.</p>
      </footer>

      {/* Add Student Modal */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl space-y-4 relative animate-in fade-in zoom-in-95 duration-200">
            <button 
              onClick={() => setShowAddStudentModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 text-lg font-bold"
            >
              ✕
            </button>
            <div>
              <h3 className="text-xl font-extrabold">Register New Resident Student</h3>
              <p className="text-xs text-slate-400 mt-1">Add student details to database registers.</p>
            </div>
            
            <form onSubmit={handleAddStudent} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Student Name</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Ramesh Dev"
                    required
                    value={newStudentName}
                    onChange={e => setNewStudentName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500 mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="ramesh@college.edu"
                    required
                    value={newStudentEmail}
                    onChange={e => setNewStudentEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500 mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Roll Number</label>
                  <input 
                    type="text" 
                    placeholder="NITK-CSE-2023-99"
                    required
                    value={newStudentRoll}
                    onChange={e => setNewStudentRoll(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500 mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Gender</label>
                  <select 
                    value={newStudentGender}
                    onChange={e => setNewStudentGender(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs focus:outline-none mt-1 text-slate-100 bg-slate-950"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Department</label>
                  <input 
                    type="text" 
                    placeholder="CSE"
                    value={newStudentDept}
                    onChange={e => setNewStudentDept(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-2 text-xs mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Branch</label>
                  <input 
                    type="text" 
                    placeholder="IT"
                    value={newStudentBranch}
                    onChange={e => setNewStudentBranch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-2 text-xs mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Year of Study</label>
                  <input 
                    type="number" 
                    min="1" 
                    max="5"
                    value={newStudentYear}
                    onChange={e => setNewStudentYear(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-2 text-xs mt-1 text-slate-100 bg-slate-950"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddStudentModal(false)}
                  className="flex-1 bg-slate-850 hover:bg-slate-800 text-slate-200 text-xs font-bold py-2.5 rounded-xl transition-all border border-slate-750"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs font-bold py-2.5 rounded-xl hover:opacity-90 transition-all"
                >
                  Add Resident Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Generated Student Credentials Modal */}
      {newStudentCredentials && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4 relative animate-in fade-in zoom-in-95 duration-200 text-slate-100">
            <div className="text-center space-y-2">
              <div className="inline-flex bg-emerald-500/10 p-3 rounded-full border border-emerald-500/20 mb-2">
                <Check className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-100">Student Account Created!</h3>
              <p className="text-xs text-slate-400">Share these generated login credentials with the student:</p>
            </div>

            <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-2 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span className="text-slate-500 font-bold">Student Name:</span>
                <span className="text-slate-200">{newStudentCredentials.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span className="text-slate-500 font-bold">Unique ID/Email:</span>
                <span className="text-slate-300 select-all font-bold">{newStudentCredentials.email}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span className="text-slate-500 font-bold">Temporary Password:</span>
                <span className="text-indigo-400 select-all font-bold">{newStudentCredentials.password}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-bold">Roll Number:</span>
                <span className="text-slate-300">{newStudentCredentials.roll}</span>
              </div>
            </div>

            <button 
              onClick={() => setNewStudentCredentials(null)}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-2.5 rounded-xl text-xs hover:opacity-90 transition-all"
            >
              Done & Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
