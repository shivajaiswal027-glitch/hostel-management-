# College Hostel Management Portal

This project provides a comprehensive, centralized Hostel Management Portal for colleges, replacing manual paper registers, scattered chat messages, and fragmented processes.

## Tech Stack
- **Frontend**: React / Next.js (Tailwind CSS)
- **Backend**: Node.js (Express)
- **Database**: PostgreSQL (Relational, robust transactional handling)
- **State/Caching**: Redis for session management, live gate activity, and real-time notification queues
- **Payment Gateway**: Razorpay (primary), with Stripe fallback compatibility
- **Notification Channels**: Twilio (WhatsApp + SMS), SendGrid/AWS SES (Email), WebSockets (In-App)

## Workspace Recommendation
To start development immediately:
1. Open this subdirectory (`C:\Users\dell\.gemini\antigravity-ide\scratch\hostel-management`) as your active IDE workspace.
2. Initialize backend dependencies in the `backend/` folder and frontend dependencies in the `frontend/` folder.
3. Apply the database schema from [schema.sql](file:///C:/Users/dell/.gemini/antigravity-ide/scratch/hostel-management/schema.sql) in your local PostgreSQL database.

## Architecture Blueprint
For the complete detailed database schema, project structures, AI blueprints, and code flows, please refer to the system architecture design document:
- [implementation_plan.md](file:///C:/Users/dell/.gemini/antigravity-ide/brain/b14863fa-82b6-476d-a1a3-671142087d47/implementation_plan.md)
