const http = require('http');
const app = require('./app');
const { Server } = require('socket.io');
const notificationService = require('./services/notification.service');

const PORT = process.env.PORT || 5000;

// Create HTTP server
const server = http.createServer(app);

// Setup Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Pass Socket.io instance to App configuration (so controllers can use it via req.app.get)
app.set('socketio', io);

// Feed instance to Notification Service for active alert push triggers
notificationService.setIo(io);

// Handle WebSockets connection activity
io.on('connection', (socket) => {
  console.log(`Socket client connected: ${socket.id}`);

  // Join a dedicated channel for user specific push notifications
  socket.on('register_user', (userId) => {
    socket.join(userId);
    console.log(`Socket registered to user channel: ${userId}`);
  });

  socket.on('disconnect', () => {
    console.log(`Socket client disconnected: ${socket.id}`);
  });
});

// Start Server
server.listen(PORT, () => {
  console.log(`===================================================`);
  console.log(`Hostel Portal Backend is running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`College: ${process.env.COLLEGE_NAME || 'College Hostel'}`);
  console.log(`===================================================`);
});

module.exports = server;
