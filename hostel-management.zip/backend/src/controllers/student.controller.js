const db = require('../config/database');
const crypto = require('crypto');

/**
 * Get Student Dashboard metrics & logs
 */
exports.getDashboard = async (req, res) => {
  try {
    // 1. Fetch student's profile & room allocation
    const studentRes = await db.query(
      'SELECT id, wallet_balance FROM students WHERE user_id = $1',
      [req.user.id]
    );

    if (studentRes.rows.length === 0) {
      return res.status(404).json({ error: 'Student profile not found.' });
    }

    const student = studentRes.rows[0];

    // 2. Fetch room allocation & roommates
    const allocationRes = await db.query(
      `SELECT a.id, r.room_number, b.name AS block_name, bed.bed_number, r.id as room_id
       FROM allocations a
       JOIN rooms r ON a.room_id = r.id
       JOIN blocks b ON r.block_id = b.id
       JOIN beds bed ON a.bed_id = bed.id
       WHERE a.student_id = $1 AND a.status = 'ACTIVE'`,
      [student.id]
    );

    let roomDetails = null;
    let roommates = [];
    
    if (allocationRes.rows.length > 0) {
      roomDetails = allocationRes.rows[0];

      // Query roommate details (other active allocations in the same room)
      const roommatesRes = await db.query(
        `SELECT u.name, u.email, u.phone, s.roll_number
         FROM allocations a
         JOIN students s ON a.student_id = s.id
         JOIN users u ON s.user_id = u.id
         WHERE a.room_id = $1 AND a.student_id != $2 AND a.status = 'ACTIVE'`,
        [roomDetails.room_id, student.id]
      );
      roommates = roommatesRes.rows;
    }

    // 3. Fetch outstanding bills
    const billsRes = await db.query(
      `SELECT id, type, amount, remaining_balance, due_date, status
       FROM bills
       WHERE student_id = $1 AND status != 'PAID'
       ORDER BY due_date ASC`,
      [student.id]
    );

    // 4. Fetch recent notifications (limit 5)
    const notificationsRes = await db.query(
      `SELECT id, message, sent_at
       FROM notification_queues
       WHERE user_id = $1
       ORDER BY sent_at DESC LIMIT 5`,
      [req.user.id]
    );

    return res.status(200).json({
      success: true,
      roomDetails,
      roommates,
      walletBalance: student.wallet_balance,
      outstandingBills: billsRes.rows,
      recentNotifications: notificationsRes.rows
    });
  } catch (error) {
    console.error('Student dashboard error:', error);
    return res.status(500).json({ error: 'Failed to fetch student dashboard details.' });
  }
};

/**
 * Get Student Profile
 */
exports.getProfile = async (req, res) => {
  try {
    const profileRes = await db.query(
      `SELECT u.name, u.email, u.phone, s.roll_number, s.department, s.branch, 
              s.year_of_study, s.guardian_name, s.guardian_phone, s.medical_info, s.wallet_balance
       FROM students s
       JOIN users u ON s.user_id = u.id
       WHERE u.id = $1`,
      [req.user.id]
    );

    if (profileRes.rows.length === 0) {
      return res.status(404).json({ error: 'Student profile not found.' });
    }

    return res.status(200).json({ success: true, profile: profileRes.rows[0] });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Server error retrieving profile.' });
  }
};

/**
 * Update emergency contact / medical details
 */
exports.updateProfile = async (req, res) => {
  const { guardianName, guardianPhone, medicalInfo } = req.body;

  try {
    const updated = await db.query(
      `UPDATE students
       SET guardian_name = COALESCE($1, guardian_name),
           guardian_phone = COALESCE($2, guardian_phone),
           medical_info = COALESCE($3, medical_info),
           updated_at = NOW()
       WHERE user_id = $4 RETURNING *`,
      [guardianName, guardianPhone, medicalInfo, req.user.id]
    );

    return res.status(200).json({ success: true, student: updated.rows[0] });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to update profile details.' });
  }
};

/**
 * Request Room Change
 */
exports.requestRoomChange = async (req, res) => {
  const { requestedRoomType, reason } = req.body;

  try {
    const studentRes = await db.query('SELECT id FROM students WHERE user_id = $1', [req.user.id]);
    const studentId = studentRes.rows[0].id;

    // Get current allocation
    const allocationRes = await db.query(
      "SELECT id FROM allocations WHERE student_id = $1 AND status = 'ACTIVE'",
      [studentId]
    );

    if (allocationRes.rows.length === 0) {
      return res.status(400).json({ error: 'You must have an active room allocation first.' });
    }

    const currentAllocationId = allocationRes.rows[0].id;

    await db.query(
      `INSERT INTO room_change_requests (student_id, current_allocation_id, requested_room_type, reason)
       VALUES ($1, $2, $3, $4)`,
      [studentId, currentAllocationId, requestedRoomType || 'DOUBLE', reason]
    );

    return res.status(201).json({
      success: true,
      message: 'Room change request submitted to Warden successfully.'
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to submit room change request.' });
  }
};

/**
 * Request Night-out / Home Leave
 */
exports.applyLeave = async (req, res) => {
  const { leaveType, startDate, endDate, reason } = req.body;

  try {
    const studentRes = await db.query('SELECT id FROM students WHERE user_id = $1', [req.user.id]);
    const studentId = studentRes.rows[0].id;

    // Generate unique gate pass token
    const gatePassQr = `LEAVE_${crypto.randomBytes(12).toString('hex')}`;

    await db.query(
      `INSERT INTO leaves (student_id, type, start_date, end_date, reason, status, gate_pass_qr)
       VALUES ($1, $2, $3, $4, $5, 'PENDING', $6)`,
      [studentId, leaveType || 'NIGHT_OUT', startDate, endDate, reason, gatePassQr]
    );

    return res.status(201).json({
      success: true,
      message: 'Leave application submitted. Waiting for Warden approval.'
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to apply for leave.' });
  }
};

/**
 * Get active approved leaves (to scan QR pass)
 */
exports.getApprovedPass = async (req, res) => {
  try {
    const studentRes = await db.query('SELECT id FROM students WHERE user_id = $1', [req.user.id]);
    const studentId = studentRes.rows[0].id;

    const leavesRes = await db.query(
      `SELECT id, type, start_date, end_date, status, gate_pass_qr
       FROM leaves
       WHERE student_id = $1 AND status = 'APPROVED' AND end_date >= NOW()
       ORDER BY start_date ASC`,
      [studentId]
    );

    return res.status(200).json({ success: true, passes: leavesRes.rows });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Server error retrieving passes.' });
  }
};

/**
 * Submit Absent from meal report to reduce food wastage
 */
exports.markMessAbsent = async (req, res) => {
  const { date, mealType } = req.body; // mealType: 'BREAKFAST', 'LUNCH', 'DINNER'
  
  // Implementation note: In production, insert into a `mess_absentee_logs` table.
  // Here we return mock confirmation to student client dashboard.
  return res.status(200).json({
    success: true,
    message: `Absence logged for ${mealType} on ${date}. Thank you for helping reduce food waste!`
  });
};
