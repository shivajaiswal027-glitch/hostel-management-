const db = require('../config/database');
const notificationService = require('../services/notification.service');

/**
 * Get Admin dashboard central metrics
 */
exports.getDashboardMetrics = async (req, res) => {
  try {
    // 1. Total occupancy rate
    const bedStats = await db.query(
      `SELECT 
         COUNT(*) as total_beds,
         SUM(CASE WHEN is_occupied = true THEN 1 ELSE 0 END) as occupied_beds
       FROM beds`
    );
    const { total_beds, occupied_beds } = bedStats.rows[0];
    const occupancyPercentage = total_beds > 0 ? ((occupied_beds / total_beds) * 100).toFixed(1) : 0;

    // 2. Fees collected vs pending
    const billStats = await db.query(
      `SELECT 
         SUM(amount) as total_invoiced,
         SUM(remaining_balance) as total_pending,
         SUM(amount - remaining_balance) as total_collected
       FROM bills`
    );
    const billingMetrics = billStats.rows[0];

    // 3. Active open complaints
    const complaintsStats = await db.query(
      `SELECT COUNT(*) as active_tickets FROM complaints WHERE status != 'RESOLVED'`
    );
    const activeComplaintsCount = complaintsStats.rows[0].active_tickets;

    // 4. Students currently outside (leaves approved and checked out)
    const leavesStats = await db.query(
      `SELECT COUNT(DISTINCT l.student_id) as outside_count
       FROM leaves l
       JOIN gate_logs gl ON gl.user_id = (SELECT user_id FROM students WHERE id = l.student_id)
       WHERE l.status = 'APPROVED' 
         AND NOW() BETWEEN l.start_date AND l.end_date`
    );
    const outsideCount = leavesStats.rows[0].outside_count;

    return res.status(200).json({
      success: true,
      metrics: {
        occupancyRate: `${occupancyPercentage}%`,
        occupiedBeds: parseInt(occupied_beds, 10),
        totalBeds: parseInt(total_beds, 10),
        billing: {
          totalInvoiced: parseFloat(billingMetrics.total_invoiced || 0),
          totalPending: parseFloat(billingMetrics.total_pending || 0),
          totalCollected: parseFloat(billingMetrics.total_collected || 0)
        },
        activeComplaints: parseInt(activeComplaintsCount, 10),
        studentsOutside: parseInt(outsideCount || 0, 10)
      }
    });
  } catch (error) {
    console.error('Admin metrics error:', error);
    return res.status(500).json({ error: 'Failed to retrieve admin dashboard metrics.' });
  }
};

/**
 * Smart Automated Room Allocation Engine
 * Matches unallocated students to available beds based on department / year of study
 */
exports.allocateRoomAuto = async (req, res) => {
  try {
    // 1. Get all students currently without active allocations
    const unallocatedStudents = await db.query(
      `SELECT s.id, s.roll_number, s.department, s.year_of_study, s.gender, s.user_id
       FROM students s
       LEFT JOIN allocations a ON s.id = a.student_id AND a.status = 'ACTIVE'
       WHERE a.id IS NULL`
    );

    if (unallocatedStudents.rows.length === 0) {
      return res.status(200).json({ success: true, message: 'All students are already allocated rooms.' });
    }

    // 2. Get active academic year
    const acadYearRes = await db.query('SELECT id FROM academic_years WHERE is_active = true LIMIT 1');
    if (acadYearRes.rows.length === 0) {
      return res.status(400).json({ error: 'No active academic year found. Cannot allocate rooms.' });
    }
    const academicYearId = acadYearRes.rows[0].id;

    let allocationCount = 0;

    // Start database transaction
    await db.pool.query('BEGIN');

    for (const student of unallocatedStudents.rows) {
      // Find an available bed in a room that matches the student's gender and has room capacity
      // Matching heuristic: try to find a room with same-year roommates, otherwise any available bed
      const queryMatchingBed = `
        SELECT b.id AS bed_id, r.id AS room_id
        FROM beds b
        JOIN rooms r ON b.room_id = r.id
        JOIN blocks bl ON r.block_id = bl.id
        WHERE b.is_occupied = false AND b.is_under_maintenance = false
          AND bl.gender_restriction = $1
          AND r.is_active = true
        ORDER BY (
          SELECT COUNT(*) 
          FROM allocations a 
          JOIN students s ON a.student_id = s.id
          WHERE a.room_id = r.id AND a.status = 'ACTIVE' AND s.year_of_study = $2
        ) DESC
        LIMIT 1
      `;

      const bedMatch = await db.query(queryMatchingBed, [student.gender, student.year_of_study]);

      if (bedMatch.rows.length > 0) {
        const { bed_id, room_id } = bedMatch.rows[0];

        // Create active allocation record
        await db.query(
          `INSERT INTO allocations (student_id, room_id, bed_id, academic_year_id, start_date)
           VALUES ($1, $2, $3, $4, CURRENT_DATE)`,
          [student.id, room_id, bed_id, academic_yearId]
        );

        // Mark bed as occupied
        await db.query('UPDATE beds SET is_occupied = true WHERE id = $1', [bed_id]);

        // Trigger notification
        await notificationService.send({
          userId: student.user_id,
          title: 'Room Allocated',
          message: 'Your hostel room has been successfully allocated. Check room tracker on dashboard.',
          channels: ['EMAIL', 'IN_APP']
        });

        allocationCount++;
      }
    }

    await db.pool.query('COMMIT');

    return res.status(200).json({
      success: true,
      message: `Automated matching algorithm completed. Allocated ${allocationCount} students.`,
      allocatedCount: allocationCount
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error('Auto allocation engine error:', error);
    return res.status(500).json({ error: 'Automated allocation process failed.' });
  }
};

/**
 * Review leave requests (Approve / Reject)
 */
exports.reviewLeaveRequest = async (req, res) => {
  const { leaveId, status, wardenNotes } = req.body; // status: 'APPROVED' or 'REJECTED'

  try {
    // 1. Update leave request status
    const leaveUpdate = await db.query(
      `UPDATE leaves
       SET status = $1, approved_by = $2, updated_at = NOW()
       WHERE id = $3 RETURNING student_id, type`,
      [status, req.user.id, leaveId]
    );

    if (leaveUpdate.rows.length === 0) {
      return res.status(404).json({ error: 'Leave request not found.' });
    }

    const { student_id, type } = leaveUpdate.rows[0];

    // Fetch user id of the student to trigger notifications
    const studentUser = await db.query('SELECT user_id FROM students WHERE id = $1', [student_id]);
    const userId = studentUser.rows[0].user_id;

    // 2. Notify student
    await notificationService.send({
      userId,
      title: `Leave Request ${status}`,
      message: `Your application for ${type} leave has been ${status.toLowerCase()} by Warden.${wardenNotes ? ` Notes: ${wardenNotes}` : ''}`,
      channels: ['EMAIL', 'IN_APP', 'WHATSAPP']
    });

    return res.status(200).json({
      success: true,
      message: `Leave request status updated to ${status}. Notification dispatched.`
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to update leave request status.' });
  }
};

/**
 * Send broadcast announcement to multiple students
 */
exports.broadcastAnnouncement = async (req, res) => {
  const { blockId, yearOfStudy, title, message, channels } = req.body;

  try {
    // Build SQL dynamically based on targeting
    let queryStr = `
      SELECT s.user_id 
      FROM students s
      LEFT JOIN allocations a ON s.id = a.student_id AND a.status = 'ACTIVE'
      LEFT JOIN rooms r ON a.room_id = r.id
      WHERE 1=1
    `;
    const params = [];

    if (blockId) {
      params.push(blockId);
      queryStr += ` AND r.block_id = $${params.length}`;
    }

    if (yearOfStudy) {
      params.push(yearOfStudy);
      queryStr += ` AND s.year_of_study = $${params.length}`;
    }

    const recipients = await db.query(queryStr, params);

    if (recipients.rows.length === 0) {
      return res.status(200).json({ success: true, message: 'No recipients matched filter targets.' });
    }

    // Dispatch broadcast notifications
    for (const r of recipients.rows) {
      // Send as separate promises/worker tasks to avoid blocking thread
      notificationService.send({
        userId: r.user_id,
        title,
        message,
        channels: channels || ['EMAIL', 'IN_APP']
      }).catch(err => console.error('Broadcast dispatch error:', err));
    }

    return res.status(200).json({
      success: true,
      message: `Broadcast queued successfully for ${recipients.rows.length} students.`
    });
  } catch (error) {
    console.error('Broadcast error:', error);
    return res.status(500).json({ error: 'Failed to dispatch broadcast announcement.' });
  }
};

/**
 * Generate Fee Defaulters Audit Report
 */
exports.getDefaultersReport = async (req, res) => {
  try {
    const query = `
      SELECT u.name, u.email, u.phone, s.roll_number, s.department, s.branch, 
             b.type AS bill_type, b.amount, b.remaining_balance, b.due_date
      FROM bills b
      JOIN students s ON b.student_id = s.id
      JOIN users u ON s.user_id = u.id
      WHERE b.status != 'PAID' AND b.due_date < CURRENT_DATE
      ORDER BY b.remaining_balance DESC
    `;

    const report = await db.query(query);

    return res.status(200).json({
      success: true,
      defaulters: report.rows,
      generatedAt: new Date()
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to generate financial audit reports.' });
  }
};

/**
 * List all students in database
 */
exports.getStudents = async (req, res) => {
  try {
    const studentsRes = await db.query(
      `SELECT s.id, u.name, u.email, u.phone, s.roll_number, s.department, s.branch, s.year_of_study, s.gender,
              r.room_number, bl.name AS block_name
       FROM students s
       JOIN users u ON s.user_id = u.id
       LEFT JOIN allocations a ON s.id = a.student_id AND a.status = 'ACTIVE'
       LEFT JOIN rooms r ON a.room_id = r.id
       LEFT JOIN blocks bl ON r.block_id = bl.id
       ORDER BY u.name ASC`
    );

    return res.status(200).json({
      success: true,
      students: studentsRes.rows
    });
  } catch (error) {
    console.error('Get students list error:', error);
    return res.status(500).json({ error: 'Failed to retrieve students directory.' });
  }
};

/**
 * Register a student by admin
 */
exports.registerStudent = async (req, res) => {
  const {
    name,
    email,
    phone,
    rollNumber,
    department,
    branch,
    yearOfStudy,
    gender,
    guardianName,
    guardianPhone,
    medicalInfo
  } = req.body;

  const tempPassword = `NITK-${Math.floor(1000 + Math.random() * 9000)}`;

  try {
    const userCheck = await db.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email already exists.' });
    }

    const roleRes = await db.query("SELECT id FROM roles WHERE name = 'STUDENT'");
    if (roleRes.rows.length === 0) {
      return res.status(500).json({ error: 'STUDENT role is not initialized in database.' });
    }
    const studentRoleId = roleRes.rows[0].id;

    // Fetch batch (default to first active batch)
    const batchRes = await db.query(
      `SELECT b.id FROM batches b
       JOIN academic_years a ON b.academic_year_id = a.id
       WHERE a.is_active = true LIMIT 1`
    );
    const batchId = batchRes.rows[0]?.id;

    const bcrypt = require('bcryptjs');
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(tempPassword, salt);

    await db.pool.query('BEGIN');

    // Create User
    const userInsert = await db.query(
      `INSERT INTO users (role_id, name, email, password_hash, phone)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [studentRoleId, name, email, passwordHash, phone || `+910000000000`]
    );
    const newUserId = userInsert.rows[0].id;

    // Create Student Profile
    await db.query(
      `INSERT INTO students (user_id, roll_number, department, branch, year_of_study, batch_id, gender, guardian_name, guardian_phone, medical_info)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        newUserId,
        rollNumber,
        department,
        branch,
        parseInt(yearOfStudy, 10),
        batchId,
        gender || 'MALE',
        guardianName || 'Guardian',
        guardianPhone || '+910000000000',
        medicalInfo || ''
      ]
    );

    await db.pool.query('COMMIT');

    // Notify student about login credentials (mock/real)
    notificationService.send({
      userId: newUserId,
      title: 'Hostel Hub Account Created',
      message: `Welcome ${name}! Your account has been registered by the admin. Log in using email: ${email} and password: ${tempPassword}`,
      channels: ['EMAIL', 'IN_APP']
    }).catch(err => console.error('Welcoming alert failed:', err.message));

    return res.status(201).json({
      success: true,
      message: 'Student account and profile created successfully.',
      credentials: {
        email,
        password: tempPassword,
        rollNumber
      }
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error('Admin student registration error:', error);
    return res.status(500).json({ error: 'Student registration failed.' });
  }
};

/**
 * Delete a student and their associated user account
 */
exports.deleteStudent = async (req, res) => {
  const { id } = req.params; // student ID (primary key in students table)

  try {
    // 1. Fetch user_id of student first
    const studentRes = await db.query('SELECT user_id, roll_number FROM students WHERE id = $1', [id]);
    if (studentRes.rows.length === 0) {
      return res.status(404).json({ error: 'Student not found.' });
    }
    const { user_id, roll_number } = studentRes.rows[0];

    // Start transaction to clean up allocations and profiles
    await db.pool.query('BEGIN');

    // Free any occupied beds
    const allocationsRes = await db.query(
      `SELECT bed_id FROM allocations WHERE student_id = $1 AND status = 'ACTIVE'`,
      [id]
    );
    for (const alloc of allocationsRes.rows) {
      await db.query('UPDATE beds SET is_occupied = false WHERE id = $1', [alloc.bed_id]);
    }
    await db.query(`UPDATE allocations SET status = 'TERMINATED' WHERE student_id = $1`, [id]);

    // Delete student and user records (cascade will take care of profiles but let's delete user)
    await db.query('DELETE FROM users WHERE id = $1', [user_id]);

    await db.pool.query('COMMIT');

    return res.status(200).json({
      success: true,
      message: `Student with roll number ${roll_number} has been deleted and room allocation terminated.`
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error('Delete student error:', error);
    return res.status(500).json({ error: 'Failed to delete student account.' });
  }
};

