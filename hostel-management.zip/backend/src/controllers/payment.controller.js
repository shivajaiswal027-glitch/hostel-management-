const Razorpay = require('razorpay');
const crypto = require('crypto');
const db = require('../config/database');
const notificationService = require('../services/notification.service');

const razorpayKeyId = process.env.RAZORPAY_KEY_ID || 'rzp_test_dummyKeyId123';
const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET || 'dummySecretValue12345';

let razorpayInstance;
if (razorpayKeyId && razorpayKeyId !== 'rzp_test_dummyKeyId123') {
  razorpayInstance = new Razorpay({
    key_id: razorpayKeyId,
    key_secret: razorpayKeySecret
  });
} else {
  console.warn('Razorpay keys are unconfigured. Payments will run in simulation mode.');
  razorpayInstance = null;
}

/**
 * Initialize a bill payment by creating a Razorpay Order
 */
exports.createOrder = async (req, res) => {
  const { billId, amount } = req.body;

  try {
    // 1. Validate the bill exists and has a remaining balance
    const billRes = await db.query(
      'SELECT id, remaining_balance, student_id FROM bills WHERE id = $1',
      [billId]
    );

    if (billRes.rows.length === 0) {
      return res.status(404).json({ error: 'Bill record not found.' });
    }

    const bill = billRes.rows[0];
    const amountFloat = parseFloat(amount);

    if (amountFloat <= 0 || amountFloat > parseFloat(bill.remaining_balance)) {
      return res.status(400).json({ error: 'Invalid payment amount specified.' });
    }

    // 2. Setup order options (Razorpay expects amount in paise)
    const options = {
      amount: Math.round(amountFloat * 100),
      currency: 'INR',
      receipt: `bill_payment_${billId}_${Date.now()}`
    };

    let orderId;
    if (razorpayInstance) {
      const order = await razorpayInstance.orders.create(options);
      orderId = order.id;
    } else {
      // Simulation mode order ID
      orderId = `order_sim_${crypto.randomBytes(8).toString('hex')}`;
    }

    // 3. Insert payment log with status 'PENDING'
    await db.query(
      `INSERT INTO payments (bill_id, user_id, amount, transaction_id, status)
       VALUES ($1, $2, $3, $4, 'PENDING')`,
      [billId, req.user.id, amountFloat, orderId]
    );

    return res.status(200).json({
      success: true,
      orderId,
      amount: options.amount,
      currency: options.currency,
      keyId: razorpayKeyId,
      isSimulation: !razorpayInstance
    });
  } catch (error) {
    console.error('Create payment order error:', error);
    return res.status(500).json({ error: 'Failed to initialize payment process.' });
  }
};

/**
 * Verify Razorpay payment signature (standard client-side callback verification)
 */
exports.verifyPayment = async (req, res) => {
  const { paymentId, orderId, signature, billId } = req.body;

  if (!razorpayInstance) {
    // In simulation mode, mock success immediately
    try {
      await processSuccessfulPayment(orderId, paymentId, 'SIMULATED_UPI', billId);
      return res.status(200).json({
        success: true,
        message: 'Payment simulated successfully.',
        receiptUrl: `/receipts/${paymentId}.pdf`
      });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Simulation processing failed' });
    }
  }

  // Calculate signature
  const body = orderId + '|' + paymentId;
  const expectedSignature = crypto
    .createHmac('sha256', razorpayKeySecret)
    .update(body.toString())
    .digest('hex');

  if (expectedSignature === signature) {
    try {
      await processSuccessfulPayment(orderId, paymentId, 'VERIFIED_API', billId);
      return res.status(200).json({
        success: true,
        message: 'Payment verified and captured.',
        receiptUrl: `/receipts/${paymentId}.pdf`
      });
    } catch (error) {
      console.error('Capture update error:', error);
      return res.status(500).json({ error: 'Failed to sync payment status in database.' });
    }
  } else {
    return res.status(400).json({ error: 'Invalid checkout signature validation.' });
  }
};

/**
 * Handle Razorpay Webhook Event Notifications
 */
exports.handleWebhook = async (req, res) => {
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET || 'dummyWebhookSecret98765';
  const signature = req.headers['x-razorpay-signature'];

  // Check signature if it isn't a simulation or dummy webhook trigger
  if (razorpayInstance && signature) {
    const expectedSignature = crypto
      .createHmac('sha256', webhookSecret)
      .update(JSON.stringify(req.body))
      .digest('hex');

    if (expectedSignature !== signature) {
      return res.status(400).json({ error: 'Webhook signature mismatch.' });
    }
  }

  const event = req.body.event;
  const payload = req.body.payload;

  if (event === 'payment.captured') {
    const paymentEntity = payload.payment.entity;
    const orderId = paymentEntity.order_id;
    const paymentId = paymentEntity.id;
    const method = paymentEntity.method;

    try {
      // Find bill ID associated with this payment attempt
      const paymentLog = await db.query(
        'SELECT bill_id FROM payments WHERE transaction_id = $1',
        [orderId]
      );

      const billId = paymentLog.rows[0]?.bill_id;
      await processSuccessfulPayment(orderId, paymentId, method, billId);
    } catch (err) {
      console.error('Webhook processing failed:', err.message);
    }
  }

  return res.status(200).json({ status: 'ok' });
};

/**
 * Private helper to handle billing updates and notifications
 */
async function processSuccessfulPayment(orderId, paymentId, method, billId) {
  // Check if payment is already captured
  const checkPayment = await db.query(
    'SELECT status, amount, user_id FROM payments WHERE transaction_id = $1 OR transaction_id = $2',
    [orderId, paymentId]
  );

  if (checkPayment.rows.length === 0) return;
  const paymentRecord = checkPayment.rows[0];

  if (paymentRecord.status !== 'CAPTURED') {
    // 1. Update Payment status
    await db.query(
      `UPDATE payments 
       SET status = 'CAPTURED', transaction_id = $1, payment_method = $2, receipt_url = $3, updated_at = NOW()
       WHERE transaction_id = $4`,
      [paymentId, method, `/receipts/${paymentId}.pdf`, orderId]
    );

    if (billId) {
      // 2. Fetch bill balance details
      const billRes = await db.query(
        'SELECT remaining_balance, type FROM bills WHERE id = $1',
        [billId]
      );
      
      if (billRes.rows.length > 0) {
        const bill = billRes.rows[0];
        const newBalance = Math.max(0, parseFloat(bill.remaining_balance) - parseFloat(paymentRecord.amount));
        const nextStatus = newBalance <= 0 ? 'PAID' : 'PARTIALLY_PAID';

        // 3. Update Bill
        await db.query(
          `UPDATE bills 
           SET remaining_balance = $1, status = $2, updated_at = NOW() 
           WHERE id = $3`,
          [newBalance, nextStatus, billId]
        );

        // 4. Notify student
        await notificationService.send({
          userId: paymentRecord.user_id,
          title: 'Payment Successful',
          message: `Your payment of ₹${paymentRecord.amount} for ${bill.type} Bill has been captured. Status: ${nextStatus}.`,
          channels: ['EMAIL', 'IN_APP', 'WHATSAPP']
        });
      }
    }
  }
}
