const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_jwt_sign_key_change_me_in_production';

/**
 * Handle Login for all portals
 */
exports.login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Please provide email and password.' });
  }

  try {
    // Check if user exists
    const userRes = await db.query(
      `SELECT u.id, u.name, u.email, u.password_hash, u.is_active, r.name AS role_name 
       FROM users u
       JOIN roles r ON u.role_id = r.id
       WHERE u.email = $1`,
      [email]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = userRes.rows[0];

    if (!user.is_active) {
      return res.status(403).json({ error: 'Your account is deactivated. Contact management.' });
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Sign JWT
    const token = jwt.sign({ id: user.id, role: user.role_name }, JWT_SECRET, {
      expiresIn: '24h'
    });

    return res.status(200).json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role_name
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Server login error.' });
  }
};

/**
 * Register a Student and create their profile
 */
exports.registerStudent = async (req, res) => {
  const {
    name,
    email,
    password,
    phone,
    rollNumber,
    department,
    branch,
    yearOfStudy,
    gender,
    guardianName,
    guardianPhone,
    medicalInfo
  } = req.body;

  try {
    // Verify user doesn't already exist
    const userCheck = await db.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email already exists.' });
    }

    // Fetch STUDENT role ID
    const roleRes = await db.query("SELECT id FROM roles WHERE name = 'STUDENT'");
    if (roleRes.rows.length === 0) {
      return res.status(500).json({ error: 'Role records are not initialized.' });
    }
    const studentRoleId = roleRes.rows[0].id;

    // Fetch batch (default to first active batch)
    const batchRes = await db.query(
      `SELECT b.id FROM batches b
       JOIN academic_years a ON b.academic_year_id = a.id
       WHERE a.is_active = true LIMIT 1`
    );
    const batchId = batchRes.rows[0]?.id;

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Start db transaction
    await db.pool.query('BEGIN');

    // Create User
    const userInsert = await db.query(
      `INSERT INTO users (role_id, name, email, password_hash, phone)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [studentRoleId, name, email, passwordHash, phone]
    );
    const newUserId = userInsert.rows[0].id;

    // Create Student Profile
    await db.query(
      `INSERT INTO students (user_id, roll_number, department, branch, year_of_study, batch_id, gender, guardian_name, guardian_phone, medical_info)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        newUserId,
        rollNumber,
        department,
        branch,
        parseInt(yearOfStudy, 10),
        batchId,
        gender || 'MALE',
        guardianName,
        guardianPhone,
        medicalInfo
      ]
    );

    await db.pool.query('COMMIT');

    return res.status(201).json({
      success: true,
      message: 'Student account and profile created successfully. You can now login.'
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error('Student registration error:', error);
    return res.status(500).json({ error: 'Student registration failed.' });
  }
};

/**
 * Register Guest User
 */
exports.registerGuest = async (req, res) => {
  const {
    name,
    email,
    password,
    phone,
    relationToStudent,
    associatedStudentRoll,
    idProofUrl,
    idProofType
  } = req.body;

  try {
    const userCheck = await db.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'User with this email already exists.' });
    }

    const roleRes = await db.query("SELECT id FROM roles WHERE name = 'GUEST'");
    const guestRoleId = roleRes.rows[0].id;

    let associatedStudentId = null;
    if (associatedStudentRoll) {
      const studentRes = await db.query(
        'SELECT id FROM students WHERE roll_number = $1',
        [associatedStudentRoll]
      );
      associatedStudentId = studentRes.rows[0]?.id || null;
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    await db.pool.query('BEGIN');

    const userInsert = await db.query(
      `INSERT INTO users (role_id, name, email, password_hash, phone)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [guestRoleId, name, email, passwordHash, phone]
    );
    const newUserId = userInsert.rows[0].id;

    await db.query(
      `INSERT INTO guests (user_id, relation_to_student, associated_student_id, id_proof_url, id_proof_type)
       VALUES ($1, $2, $3, $4, $5)`,
      [newUserId, relationToStudent, associatedStudentId, idProofUrl || 'https://via.placeholder.com/150', idProofType || 'Aadhaar Card']
    );

    await db.pool.query('COMMIT');

    return res.status(201).json({
      success: true,
      message: 'Guest account registered successfully.'
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error('Guest registration error:', error);
    return res.status(500).json({ error: 'Guest registration failed.' });
  }
};
