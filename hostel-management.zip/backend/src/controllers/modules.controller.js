const db = require('../config/database');
const notificationService = require('../services/notification.service');

/**
 * Book laundry slots (Deducts charges from student's balance wallet or logs bill)
 */
exports.bookLaundry = async (req, res) => {
  const { slotDate, timeSlot, bundleCount } = req.body;

  try {
    const studentRes = await db.query('SELECT id, wallet_balance, user_id FROM students WHERE user_id = $1', [req.user.id]);
    const student = studentRes.rows[0];

    const pricePerBundle = 15.00;
    const totalCost = parseFloat(bundleCount) * pricePerBundle;

    if (parseFloat(student.wallet_balance) < totalCost) {
      return res.status(400).json({ error: `Insufficient wallet balance. Total cost: ₹${totalCost}. Your wallet balance: ₹${student.wallet_balance}.` });
    }

    await db.pool.query('BEGIN');

    // 1. Deduct from wallet
    await db.query(
      'UPDATE students SET wallet_balance = wallet_balance - $1 WHERE id = $2',
      [totalCost, student.id]
    );

    // 2. Insert laundry booking
    await db.query(
      `INSERT INTO laundry_slots (student_id, slot_date, time_slot, bundle_count, price, payment_status, status)
       VALUES ($1, $2, $3, $4, $5, 'CAPTURED', 'BOOKED')`,
      [student.id, slotDate, timeSlot, bundleCount, totalCost]
    );

    await db.pool.query('COMMIT');

    // Notify student
    await notificationService.send({
      userId: req.user.id,
      title: 'Laundry Booked',
      message: `Successfully booked a laundry slot on ${slotDate} at ${timeSlot}. ₹${totalCost} deducted from your wallet.`,
      channels: ['IN_APP', 'EMAIL']
    });

    return res.status(201).json({
      success: true,
      message: 'Laundry slot booked successfully. Wallet balance updated.'
    });
  } catch (error) {
    await db.pool.query('ROLLBACK');
    console.error(error);
    return res.status(500).json({ error: 'Failed to book laundry slot.' });
  }
};

/**
 * Reserve slot in Gym / Facility with active capacity constraints checks
 */
exports.bookFacility = async (req, res) => {
  const { facilityId, bookingDate, startTime, endTime } = req.body;

  try {
    const studentRes = await db.query('SELECT id FROM students WHERE user_id = $1', [req.user.id]);
    const studentId = studentRes.rows[0].id;

    // 1. Check current capacity
    const facilityRes = await db.query(
      'SELECT name, daily_capacity FROM facilities WHERE id = $1',
      [facilityId]
    );

    if (facilityRes.rows.length === 0) {
      return res.status(404).json({ error: 'Facility not found.' });
    }

    const facility = facilityRes.rows[0];

    // Count concurrent bookings for the slot
    const concurrentBookings = await db.query(
      `SELECT COUNT(*) as active_bookings
       FROM facility_bookings
       WHERE facility_id = $1 AND booking_date = $2 
         AND status = 'BOOKED'
         AND (($3 BETWEEN start_time AND end_time) OR ($4 BETWEEN start_time AND end_time))`,
      [facilityId, bookingDate, startTime, endTime]
    );

    const activeCount = parseInt(concurrentBookings.rows[0].active_bookings, 10);

    if (activeCount >= facility.daily_capacity) {
      return res.status(400).json({
        error: `Facility ${facility.name} has reached maximum occupancy for this slot. Please choose another timing.`
      });
    }

    // 2. Insert booking
    await db.query(
      `INSERT INTO facility_bookings (student_id, facility_id, booking_date, start_time, end_time, status)
       VALUES ($1, $2, $3, $4, $5, 'BOOKED')`,
      [studentId, facilityId, bookingDate, startTime, endTime]
    );

    // AI Crowd Alert trigger: check if capacity is nearing its limit
    const occupancyPercentage = ((activeCount + 1) / facility.daily_capacity) * 100;
    if (occupancyPercentage >= 85.0) {
      // Emit crowd warning to active users via WebSocket
      const io = req.app.get('socketio');
      if (io) {
        io.emit('crowd_warning', {
          facilityName: facility.name,
          occupancy: `${occupancyPercentage.toFixed(0)}%`,
          message: `The ${facility.name} is approaching maximum capacity limits.`
        });
      }
    }

    return res.status(201).json({
      success: true,
      message: `Successfully booked facility ${facility.name} slot.`
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to book facility slot.' });
  }
};

/**
 * Proxy fetch library details (Mock integration with outer college LMS library API)
 */
exports.getLibraryStatus = async (req, res) => {
  try {
    const studentRes = await db.query('SELECT roll_number FROM students WHERE user_id = $1', [req.user.id]);
    const rollNumber = studentRes.rows[0].roll_number;

    // Simulate external college Library API response payload
    const mockLibraryPayload = {
      booksIssued: [
        { title: 'Introduction to Algorithms (CLRS)', dueDate: '2026-06-25', finePending: 0.0 },
        { title: 'Database System Concepts (Silberschatz)', dueDate: '2026-06-18', finePending: 0.0 }
      ],
      totalDues: 0.0
    };

    return res.status(200).json({
      success: true,
      rollNumber,
      libraryData: mockLibraryPayload
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to query LMS proxy database.' });
  }
};
