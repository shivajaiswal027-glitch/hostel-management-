const jwt = require('jsonwebtoken');
const db = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'super_secret_jwt_sign_key_change_me_in_production';

/**
 * Protect routes by verifying the JWT bearer token.
 */
exports.protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ error: 'Not authorized, token missing.' });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET);

    // Fetch user and join with their role
    const userRes = await db.query(
      `SELECT u.id, u.name, u.email, u.phone, r.name AS role_name 
       FROM users u
       JOIN roles r ON u.role_id = r.id
       WHERE u.id = $1 AND u.is_active = true`,
      [decoded.id]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'User associated with this token no longer exists or is inactive.' });
    }

    req.user = userRes.rows[0];
    next();
  } catch (error) {
    console.error('Auth verification error:', error);
    return res.status(401).json({ error: 'Not authorized, token invalid or expired.' });
  }
};

/**
 * Role-Based Access Control check.
 * @param {...string} allowedRoles - List of allowed role names (e.g. 'STUDENT', 'WARDEN')
 */
exports.authorize = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role_name)) {
      return res.status(403).json({
        error: `Access denied. Role '${req.user?.role_name || 'GUEST'}' is not authorized to access this resource.`
      });
    }
    next();
  };
};
