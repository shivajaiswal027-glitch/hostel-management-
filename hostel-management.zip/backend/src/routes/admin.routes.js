const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);
router.use(authorize('SUPER_ADMIN', 'WARDEN'));

router.get('/metrics', adminController.getDashboardMetrics);
router.post('/allocate/auto', adminController.allocateRoomAuto);
router.put('/leaves/review', adminController.reviewLeaveRequest);
router.post('/broadcast', adminController.broadcastAnnouncement);
router.get('/reports/defaulters', adminController.getDefaultersReport);

// Student CRUD routes under admin portal
router.get('/students', adminController.getStudents);
router.post('/students', adminController.registerStudent);
router.delete('/students/:id', adminController.deleteStudent);

module.exports = router;
