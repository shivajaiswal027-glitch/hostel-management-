const express = require('express');
const router = express.Router();

const authRoutes = require('./auth.routes');
const studentRoutes = require('./student.routes');
const adminRoutes = require('./admin.routes');
const paymentRoutes = require('./payment.routes');
const modulesRoutes = require('./modules.routes');
const gateRoutes = require('./gate.routes');

router.use('/auth', authRoutes);
router.use('/student', studentRoutes);
router.use('/admin', adminRoutes);
router.use('/payment', paymentRoutes);
router.use('/modules', modulesRoutes);
router.use('/gate', gateRoutes);

module.exports = router;
