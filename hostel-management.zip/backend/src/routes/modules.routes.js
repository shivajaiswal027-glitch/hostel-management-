const express = require('express');
const router = express.Router();
const modulesController = require('../controllers/modules.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);
router.use(authorize('STUDENT'));

router.post('/laundry/book', modulesController.bookLaundry);
router.post('/facility/book', modulesController.bookFacility);
router.get('/library/status', modulesController.getLibraryStatus);

module.exports = router;
