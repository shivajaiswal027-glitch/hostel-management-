const express = require('express');
const router = express.Router();
const gateController = require('../controllers/gate.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

// Face comparison at physical gate camera (usually authenticated via device key or guard)
router.post('/verify/face', gateController.verifyFace);

// Protected endpoints for security guards
router.post('/verify/qr', protect, authorize('SECURITY_GUARD', 'WARDEN', 'SUPER_ADMIN'), gateController.verifyQrPass);
router.get('/logs', protect, authorize('SECURITY_GUARD', 'WARDEN', 'SUPER_ADMIN'), gateController.getLogs);

module.exports = router;
