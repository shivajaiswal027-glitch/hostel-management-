const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/payment.controller');
const { protect } = require('../middlewares/auth.middleware');

// Public webhook endpoint
router.post('/webhook', paymentController.handleWebhook);

// Protected endpoints
router.use(protect);
router.post('/create-order', paymentController.createOrder);
router.post('/verify', paymentController.verifyPayment);

module.exports = router;
