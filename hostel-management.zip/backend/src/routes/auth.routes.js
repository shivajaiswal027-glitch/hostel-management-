const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');

router.post('/login', authController.login);
router.post('/register/student', authController.registerStudent);
router.post('/register/guest', authController.registerGuest);

module.exports = router;
