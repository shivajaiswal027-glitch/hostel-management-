const express = require('express');
const router = express.Router();
const studentController = require('../controllers/student.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);
router.use(authorize('STUDENT'));

router.get('/dashboard', studentController.getDashboard);
router.get('/profile', studentController.getProfile);
router.put('/profile', studentController.updateProfile);
router.post('/room-change', studentController.requestRoomChange);
router.post('/leave', studentController.applyLeave);
router.get('/leave/passes', studentController.getApprovedPass);
router.post('/mess/absent', studentController.markMessAbsent);

module.exports = router;
