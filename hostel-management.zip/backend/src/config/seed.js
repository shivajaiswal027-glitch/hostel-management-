const db = require('./database');
const bcrypt = require('bcryptjs');

async function seed() {
  console.log('Starting database seeding...');
  
  try {
    // 1. Clean data (Optional / Development only)
    // For safety, we do not truncate, just check/insert.

    // 2. Seed Roles
    const roles = [
      { name: 'SUPER_ADMIN', description: 'Overall system administrator' },
      { name: 'WARDEN', description: 'Hostel manager and approval officer' },
      { name: 'SECURITY_GUARD', description: 'Gate operator and logger' },
      { name: 'STUDENT', description: 'Hostel resident student' },
      { name: 'GUEST', description: 'Temporary visitor' },
      { name: 'FACILITY_MANAGER', description: 'Laundry and Gym operator' }
    ];

    for (const r of roles) {
      await db.query(
        `INSERT INTO roles (name, description) 
         VALUES ($1, $2) 
         ON CONFLICT (name) DO NOTHING`,
        [r.name, r.description]
      );
    }
    console.log('Roles seeded successfully.');

    // Get role IDs for users seeding
    const roleMap = {};
    const roleRows = await db.query('SELECT id, name FROM roles');
    roleRows.rows.forEach(row => {
      roleMap[row.name] = row.id;
    });

    // 3. Seed Academic Year
    await db.query(
      `INSERT INTO academic_years (name, start_date, end_date, is_active)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (name) DO NOTHING`,
      ['2026-2027', '2026-06-01', '2027-05-31', true]
    );
    console.log('Academic Year seeded.');

    const acadYearRes = await db.query("SELECT id FROM academic_years WHERE name = '2026-2027'");
    const academicYearId = acadYearRes.rows[0].id;

    // 4. Seed Batches
    const batchName = 'BTech CSE 2023-2027';
    await db.query(
      `INSERT INTO batches (academic_year_id, name)
       VALUES ($1, $2)
       ON CONFLICT DO NOTHING`, // Since there is no unique constraint on batches name, we can do manual check or just insert
      [academicYearId, batchName]
    );

    const batchRes = await db.query('SELECT id FROM batches WHERE name = $1', [batchName]);
    const batchId = batchRes.rows[0]?.id;
    console.log('Batch seeded:', batchName);

    // 5. Seed Infrastructure Blocks
    const blocks = [
      { name: 'Block A', gender_restriction: 'MALE' },
      { name: 'Block D', gender_restriction: 'FEMALE' }
    ];

    for (const b of blocks) {
      await db.query(
        `INSERT INTO blocks (name, gender_restriction)
         VALUES ($1, $2)
         ON CONFLICT (name) DO NOTHING`,
        [b.name, b.gender_restriction]
      );
    }
    console.log('Blocks seeded.');

    // Fetch block IDs
    const blockMap = {};
    const blockRows = await db.query('SELECT id, name FROM blocks');
    blockRows.rows.forEach(row => {
      blockMap[row.name] = row.id;
    });

    // 6. Seed Rooms & Beds for Block A
    const roomNumbers = ['101', '102', '103'];
    for (const num of roomNumbers) {
      // Check if room exists
      const roomCheck = await db.query(
        'SELECT id FROM rooms WHERE block_id = $1 AND room_number = $2',
        [blockMap['Block A'], num]
      );

      let roomId;
      if (roomCheck.rows.length === 0) {
        const roomRes = await db.query(
          `INSERT INTO rooms (block_id, room_number, occupancy_limit, base_price_per_month)
           VALUES ($1, $2, 'DOUBLE', 6000.00) RETURNING id`,
          [blockMap['Block A'], num]
        );
        roomId = roomRes.rows[0].id;
      } else {
        roomId = roomCheck.rows[0].id;
      }

      // Seed 2 Beds per room (Double occupancy)
      for (const bedNum of ['A', 'B']) {
        await db.query(
          `INSERT INTO beds (room_id, bed_number, is_occupied)
           VALUES ($1, $2, false)
           ON CONFLICT (room_id, bed_number) DO NOTHING`,
          [roomId, bedNum]
        );
      }
    }
    console.log('Rooms & Beds seeded.');

    // 7. Seed Default Admin
    const adminEmail = 'admin@college.edu';
    const adminCheck = await db.query('SELECT id FROM users WHERE email = $1', [adminEmail]);
    if (adminCheck.rows.length === 0) {
      const hash = await bcrypt.hash('Password123', 10);
      await db.query(
        `INSERT INTO users (role_id, name, email, password_hash, phone)
         VALUES ($1, $2, $3, $4, $5)`,
        [roleMap['SUPER_ADMIN'], 'Lead Warden Admin', adminEmail, hash, '+919999999999']
      );
      console.log('Default Admin seeded (admin@college.edu / Password123).');
    }

    // 8. Seed Default Student
    const studentEmail = 'student@college.edu';
    const studentCheck = await db.query('SELECT id FROM users WHERE email = $1', [studentEmail]);
    if (studentCheck.rows.length === 0) {
      const hash = await bcrypt.hash('Password123', 10);
      const userRes = await db.query(
        `INSERT INTO users (role_id, name, email, password_hash, phone)
         VALUES ($1, $2, $3, $4, $5) RETURNING id`,
        [roleMap['STUDENT'], 'Aarav Sharma', studentEmail, hash, '+919876543210']
      );
      const newUserId = userRes.rows[0].id;

      // Seed Student Profile
      await db.query(
        `INSERT INTO students (user_id, roll_number, department, branch, year_of_study, batch_id, gender, guardian_name, guardian_phone, wallet_balance)
         VALUES ($1, $2, $3, $4, $5, $6, 'MALE', 'Ramesh Sharma', '+919888877777', 1500.00)`,
        [newUserId, 'NITK-CSE-2023-45', 'Computer Science', 'Information Technology', 3, batchId]
      );
      console.log('Default Student seeded (student@college.edu / Password123).');
    }

    // 9. Seed Default Facilities
    const facilities = [
      { name: 'Hostel Gym', daily_capacity: 40 },
      { name: 'Common Recreation Room', daily_capacity: 30 },
      { name: 'TV Lounge', daily_capacity: 25 }
    ];

    for (const f of facilities) {
      await db.query(
        `INSERT INTO facilities (name, daily_capacity)
         VALUES ($1, $2)
         ON CONFLICT (name) DO NOTHING`,
        [f.name, f.daily_capacity]
      );
    }
    console.log('Facilities seeded.');

    console.log('Seeding process completed successfully!');
  } catch (error) {
    console.error('Seeding process failed:', error);
  } finally {
    db.pool.end();
  }
}

if (require.main === module) {
  seed();
}
