const Redis = require('ioredis');
require('dotenv').config();

const redisUrl = process.env.REDIS_URL || 'redis://127.0.0.1:6379';

// Setup Redis Client with automatic reconnection and fallback logs
const redis = new Redis(redisUrl, {
  maxRetriesPerRequest: 3,
  retryStrategy(times) {
    const delay = Math.min(times * 100, 3000);
    return delay;
  }
});

redis.on('connect', () => {
  console.log('Redis client connected successfully.');
});

redis.on('error', (err) => {
  console.error('Redis client error:', err.message);
});

module.exports = redis;
