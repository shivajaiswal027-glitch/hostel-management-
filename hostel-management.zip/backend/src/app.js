const express = require('express');
const cors = require('cors');
const apiRoutes = require('./routes');

const app = express();

// Standard Middlewares
app.use(cors({ origin: '*' })); // Allow all for local/testing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Dynamic routes root binding
app.use('/api', apiRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date(),
    college: process.env.COLLEGE_NAME || 'College Hostel System'
  });
});

// Fallback Route (404)
app.use((req, res, next) => {
  res.status(404).json({ error: 'Endpoint not found.' });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Express Error Handler:', err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error occurred.'
  });
});

module.exports = app;
