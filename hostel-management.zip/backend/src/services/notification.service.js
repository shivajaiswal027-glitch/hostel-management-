const nodemailer = require('nodemailer');
const twilio = require('twilio');
const db = require('../config/database');

class NotificationService {
  constructor() {
    // Email configuration using nodemailer with default test credentials fallback
    const smtpHost = process.env.SMTP_HOST || 'smtp.mailtrap.io';
    const smtpPort = parseInt(process.env.SMTP_PORT || '2525', 10);
    const smtpUser = process.env.SMTP_USER || 'dummyUser';
    const smtpPass = process.env.SMTP_PASS || 'dummyPassword';

    this.emailTransporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: smtpPort === 465, // True for 465, false for others
      auth: {
        user: smtpUser,
        pass: smtpPass
      }
    });

    // Twilio SMS & WhatsApp fallback setup
    const twilioSid = process.env.TWILIO_ACCOUNT_SID;
    const twilioAuth = process.env.TWILIO_AUTH_TOKEN;

    if (twilioSid && twilioSid !== 'ACdummyAccountSid1234567890') {
      this.twilioClient = twilio(twilioSid, twilioAuth);
    } else {
      console.warn('Twilio keys are unconfigured. SMS & WhatsApp notifications will run in mock mode.');
      this.twilioClient = null;
    }
  }

  // Setter for socket.io instance
  setIo(io) {
    this.io = io;
  }

  /**
   * Unified send method dispatching across multiple channels
   * @param {Object} payload
   * @param {string} payload.userId - Target recipient's User ID
   * @param {string} payload.title - Subject or short title
   * @param {string} payload.message - Notification body
   * @param {Array<string>} payload.channels - e.g., ['EMAIL', 'WHATSAPP', 'SMS', 'IN_APP']
   */
  async send({ userId, title, message, channels }) {
    const userRes = await db.query(
      `SELECT email, phone, name FROM users WHERE id = $1`,
      [userId]
    );

    if (userRes.rows.length === 0) {
      throw new Error(`Recipient user not found for ID: ${userId}`);
    }
    const user = userRes.rows[0];
    const results = [];

    for (const channel of channels) {
      try {
        switch (channel.toUpperCase()) {
          case 'EMAIL':
            await this.sendEmail(user.email, title, message);
            results.push({ channel, status: 'SUCCESS' });
            break;
          case 'WHATSAPP':
            await this.sendWhatsApp(user.phone, message);
            results.push({ channel, status: 'SUCCESS' });
            break;
          case 'SMS':
            await this.sendSMS(user.phone, message);
            results.push({ channel, status: 'SUCCESS' });
            break;
          case 'IN_APP':
            await this.sendInApp(userId, title, message);
            results.push({ channel, status: 'SUCCESS' });
            break;
          default:
            results.push({ channel, status: 'FAILED', error: `Unknown channel ${channel}` });
        }
      } catch (err) {
        console.error(`Failed sending alert via ${channel}:`, err.message);
        results.push({ channel, status: 'FAILED', error: err.message });

        // Push failed message to queue table for audit/retry
        await db.query(
          `INSERT INTO notification_queues (user_id, channel, message, status, retry_count)
           VALUES ($1, $2, $3, 'FAILED', 1)`,
          [userId, channel, `${title}: ${message}`]
        );
      }
    }
    return results;
  }

  async sendEmail(toEmail, subject, bodyText) {
    const collegeName = process.env.COLLEGE_NAME || 'College Hostel';
    const mailOptions = {
      from: `"${collegeName} Portal" <noreply@college.edu>`,
      to: toEmail,
      subject: subject,
      text: bodyText,
      html: `
        <div style="font-family: sans-serif; padding: 20px; color: #333;">
          <h2 style="color: #4f46e5; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px;">${collegeName} Notification</h2>
          <p>${bodyText}</p>
          <br />
          <hr style="border: 0; border-top: 1px solid #e5e7eb;" />
          <small style="color: #6b7280;">This is an automated message. Please do not reply directly to this email.</small>
        </div>
      `
    };

    return this.emailTransporter.sendMail(mailOptions);
  }

  async sendWhatsApp(toPhone, message) {
    if (!this.twilioClient) {
      console.log(`[MOCK WHATSAPP] to ${toPhone}: ${message}`);
      return { sid: 'mock_whatsapp_sid_12345' };
    }
    const fromWhatsApp = process.env.TWILIO_WHATSAPP_NUMBER || '+14155238886';
    return this.twilioClient.messages.create({
      from: `whatsapp:${fromWhatsApp}`,
      to: `whatsapp:${toPhone}`,
      body: message
    });
  }

  async sendSMS(toPhone, message) {
    if (!this.twilioClient) {
      console.log(`[MOCK SMS] to ${toPhone}: ${message}`);
      return { sid: 'mock_sms_sid_12345' };
    }
    const fromSms = process.env.TWILIO_SMS_NUMBER || '+15017122661';
    return this.twilioClient.messages.create({
      from: fromSms,
      to: toPhone,
      body: message
    });
  }

  async sendInApp(userId, title, message) {
    // 1. Emit live Socket.io alert
    if (this.io) {
      this.io.to(userId).emit('notification', {
        title,
        message,
        timestamp: new Date()
      });
    }

    // 2. Persist to notification_queues (treated as historical logs)
    await db.query(
      `INSERT INTO notification_queues (user_id, channel, message, status)
       VALUES ($1, 'IN_APP', $2, 'SENT')`,
      [userId, `${title}: ${message}`]
    );
  }
}

// Ensure the notification_queues table matches schema.sql or fallback
// Create temporary table if not created yet (for robust initialization check)
const initNotificationDb = async () => {
  try {
    await db.query(`
      CREATE TABLE IF NOT EXISTS notification_queues (
        id SERIAL PRIMARY KEY,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        channel VARCHAR(20) NOT NULL,
        message TEXT NOT NULL,
        status VARCHAR(20) NOT NULL,
        retry_count INT DEFAULT 0,
        sent_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);
  } catch (err) {
    // Ignore if user reference doesn't exist yet
  }
};
initNotificationDb();

module.exports = new NotificationService();
